const logo = document.getElementById("logoImageLogin");

logo.addEventListener('click', function() {
    window.location.href = '../index.html';
});

const passwordInput = document.getElementById("password");
const checkBox = document.getElementById("checkBox");

function togglePassword() {
    if (checkBox.checked) {
        passwordInput.type = "text";
    } else {
        passwordInput.type = "password";
    }
}

const registerButton = document.getElementById("registerButton");

registerButton.addEventListener('click', function() {
    window.location.href = 'HTML-Files/register.html';
});
