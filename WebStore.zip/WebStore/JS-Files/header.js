const login = document.getElementById("loginIcon");
const shop = document.getElementById("shop");
const shopButton = document.getElementById("shopButton");

login.addEventListener('click', function() {
    window.location.href = 'HTML-Files/login.html';
});

shop.addEventListener('click', function() {
    window.location.href = 'HTML-Files/shop.html';
});

shopButton.addEventListener('click', function() {
    window.location.href = 'HTML-Files/shop.html';
});